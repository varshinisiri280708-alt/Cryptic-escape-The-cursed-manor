# Cryptic Escape: The Cursed Manor

## Requirements
- Python 3.10 or newer
- Pygame (installed through `requirements.txt`)
- PyInstaller (optional; only needed to package a Windows executable)

## Install and run on Windows
1. Extract this ZIP into a folder.
2. Open that folder in VS Code.
3. Open Terminal in VS Code and run:

   ```powershell
   python -m venv venv
   .\venv\Scripts\Activate.ps1
   python -m pip install -r requirements.txt
   python main.py
   ```

If PowerShell blocks activation, run this in the same terminal first:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy RemoteSigned
.\venv\Scripts\Activate.ps1
```

## Build a Windows executable (optional)
Run from the project folder after installing requirements:

```powershell
python -m PyInstaller --onedir --windowed --name CrypticEscape main.py
```

The app will be in `dist\CrypticEscape\`. Test it before sharing. If your full project uses an `assets` folder, copy that folder into the project before running/building and include it when packaging.
